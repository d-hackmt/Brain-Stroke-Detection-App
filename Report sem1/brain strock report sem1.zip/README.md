# Latex Templates

TO EDIT I RECOMMEND OVERLEAF

>Overleaf: Real-time Collaborative Writing and Publishing

Overleaf is the new collaborative writing and publishing system developed by the team behind the popular writeLaTeX editor. Overleaf is designed to make the whole process of writing, editing and producing scientific papers much quicker for both authors and publishers.

OR 
>ShareLatex
